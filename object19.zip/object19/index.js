function arrMove(arr, oldIndex, newIndex) {
    if (newIndex >= arr.length) {
      let i = newIndex - arr.length + 1;
      while (i--) {
        arr.push(undefined);
      }
    }
    arr.splice(newIndex, 0, arr.splice(oldIndex, 1)[0]);
    return arr;
  };
  console.log(arrMove([10,20,30,40,50], 0, 2));
  console.log(arrMove([10,20,30,40,50], -1, -2));