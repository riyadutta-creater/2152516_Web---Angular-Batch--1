fetch("post.json")
.then(function(res){
    return res.json();
})
.then(function(data){
    console.log(data);
})
.catch(function(err){
    console.log(err);
});

async function getPost(){
    let response = await fetch("post.json");
    let data = await response.json();
    console.log(data);
}
getPost();


