var arr=[3, 'a', 'a', 'a', 2, 3, 'a', 3, 'a', 2, 4, 9, 3];
var max = 1;
var count = 0;
var k;
for (var i=0; i<arr.length; i++)
{
        for (var j=i; j<arr.length; j++)
        {
            if (arr[i] == arr[j])
                count++;
                if (max<count)
                {
                  max=count; 
                  k = arr[i];
                }
        }
        count=0;
}
console.log(k+" ( " +max +" times ) ") ;