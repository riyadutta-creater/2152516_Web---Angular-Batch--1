//Synchronous Fetch

let data = {
    title: "Java Version 8",
    body: "object orriented programming language",
    userId: 1
}

fetch("https://jsonplaceholder.typicode.com/posts", {
    method: "POST",
    body: JSON.stringify(data),
    headers: {"Content-type": "application/json; charset=UTF-8"}
})
.then(response => response.json())
.then(json => console.log(json))
.catch(err => console.log(err));

//ASynchronous Fetch

let post={
    title:"a java book",
    body:"a very robust",
    userId:2
}

async function postData(){
    let response= await fetch('https://jsonplaceholder.typicode.com/posts',{
        method:"POST",
        body: JSON.stringify(post),
        headers: {"Content-type":"application/json"}
    })
    let data = await response.json()
    console.log(data)
}
postData();
