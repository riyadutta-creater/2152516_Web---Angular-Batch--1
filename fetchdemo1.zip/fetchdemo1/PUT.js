//Synchronous Fetch

const dataObject = {
    title: 'JavaScript',
    body: 'is the programming language of the Web',
    userId: 1,
};

fetch('https://jsonplaceholder.typicode.com/posts/1',{
    method:'PUT',
    headers:{
    'Content-Type':'application/json'
    },
    body:JSON.stringify(dataObject)
}).then(response=>{
    return response.json()
}).then(data=> 
console.log(data)
);

//Asynchronous Fetch

const myDataObject = {
    "userId": 1,
    "id": 1,
    "title": "codezup code the way up",
    "completed": false
};


const putData = async ( ) =>{
   const response = await fetch('https://jsonplaceholder.typicode.com/posts/1', {
       method: 'PUT', 
       headers: {
         'Content-Type': 'application/json'
       },
       body: JSON.stringify(myDataObject)
   });

  const data = await response.json( );
   console.log(data);
};
putData( );