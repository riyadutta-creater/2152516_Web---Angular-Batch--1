//Synchronous Fetch

fetch('https://jsonplaceholder.typicode.com/posts/1',{
    method:'DELETE'
}).then(response=>{
    return response.json()
}).then(data=> 
    console.log(data)
);

//Asynchronous Fetch

const deleteData = async ( ) =>{
    const response = await fetch('https://jsonplaceholder.typicode.com/posts/1', {
        method: 'DELETE', 
        headers: {
          'Content-Type': 'application/json'
        },
        body: null
    });
 
   const data = await response.json( );
   console.log(data);
};
deleteData( );
