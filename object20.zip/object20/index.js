var string = "ri$ya";
    try {
        if(string.includes('$')){
            throw "Wrong";
        }
        console.log("Right");
    } 
    catch (e) {
        console.log("Enter valid string");
    }
 