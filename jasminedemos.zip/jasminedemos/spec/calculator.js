class Calculator{
    add=(a,b)=>{return a+b;};
  
    sub=(a,b)=>{return a-b;};
  }
  
  module.exports=Calculator;