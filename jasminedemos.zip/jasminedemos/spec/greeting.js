let greeting = function(){
    return "good morning";
}
module.exports=greeting;
