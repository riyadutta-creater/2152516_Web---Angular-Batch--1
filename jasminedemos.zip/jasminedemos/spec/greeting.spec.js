const greeting= require('./greeting')

beforeEach(function(){
    console.log('called before each test');
})

describe("testing greeting function",function(){
    it("test return value of greeting",function(){
        expect(greeting()).toEqual("good morning");
    });
});